# Test PowerShell Script
# This is a simple script to test uploading to PSScript

# Define parameters
param(
    [string]$Name = "World",
    [int]$Times = 3
)

# Function to greet someone
function Say-Hello {
    param(
        [string]$Name,
        [int]$Count
    )
    
    for ($i = 1; $i -le $Count; $i++) {
        Write-Host "Hello, $Name! (Time $i of $Count)"
    }
}

# Call the function with the provided parameters
Say-Hello -Name $Name -Count $Times

# Show system information
Write-Host "`nSystem Information:"
Write-Host "---------------------"
Write-Host "OS: $($PSVersionTable.OS)"
Write-Host "PowerShell Version: $($PSVersionTable.PSVersion)"
Write-Host "Current Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

# Return a simple object
return @{
    ScriptName = "Test Script"
    ExecutionDateTime = Get-Date
    Parameters = @{
        Name = $Name
        Times = $Times
    }
}