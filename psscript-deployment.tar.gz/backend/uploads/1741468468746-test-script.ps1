# Simple PowerShell script for testing upload functionality
# Author: Claude
# Version: 1.0
# Date: 2025-03-08

function Get-SystemInfo {
    <#
    .SYNOPSIS
        Gets basic system information.
    
    .DESCRIPTION
        This function retrieves basic system information including OS details,
        CPU, memory, and disk space.
    
    .EXAMPLE
        Get-SystemInfo
        
        Returns system information for the local computer.
    #>
    
    [CmdletBinding()]
    param()
    
    process {
        try {
            # Get operating system information
            $OS = Get-CimInstance -ClassName Win32_OperatingSystem
            
            # Get processor information
            $CPU = Get-CimInstance -ClassName Win32_Processor
            
            # Get memory information
            $Memory = @{
                TotalGB = [math]::Round($OS.TotalVisibleMemorySize / 1MB, 2)
                FreeGB = [math]::Round($OS.FreePhysicalMemory / 1MB, 2)
                PercentFree = [math]::Round(($OS.FreePhysicalMemory / $OS.TotalVisibleMemorySize) * 100, 2)
            }
            
            # Get disk information
            $Disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" |
                     Select-Object DeviceID, 
                                  @{Name="SizeGB";Expression={[math]::Round($_.Size / 1GB, 2)}},
                                  @{Name="FreeGB";Expression={[math]::Round($_.FreeSpace / 1GB, 2)}},
                                  @{Name="PercentFree";Expression={[math]::Round(($_.FreeSpace / $_.Size) * 100, 2)}}
            
            # Return custom object with all information
            [PSCustomObject]@{
                ComputerName = $env:COMPUTERNAME
                OSName = $OS.Caption
                OSVersion = $OS.Version
                OSBuildNumber = $OS.BuildNumber
                LastBoot = $OS.LastBootUpTime
                Uptime = (Get-Date) - $OS.LastBootUpTime
                CPUName = $CPU.Name
                CPUCores = $CPU.NumberOfCores
                CPULogicalProcessors = $CPU.NumberOfLogicalProcessors
                TotalMemoryGB = $Memory.TotalGB
                FreeMemoryGB = $Memory.FreeGB
                MemoryPercentFree = $Memory.PercentFree
                Disks = $Disks
                ReportTime = Get-Date
            }
        }
        catch {
            Write-Error "Failed to get system information. Error: $_"
        }
    }
}

# Example usage
Get-SystemInfo | Format-List
