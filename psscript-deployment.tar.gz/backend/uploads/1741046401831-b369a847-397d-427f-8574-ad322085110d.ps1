# Test PowerShell script with various elements to analyze
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$InputPath,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\output.txt",
    
    [switch]$Force
)

# Function to process files
function Process-Files {
    param($path)
    
    try {
        # Check if path exists
        if (-not (Test-Path $path)) {
            throw "Path does not exist: $path"
        }
        
        # Get files
        $files = Get-ChildItem -Path $path -File
        
        # Process each file
        foreach ($file in $files) {
            Write-Verbose "Processing $($file.Name)"
            
            # Read file content
            $content = Get-Content $file.FullName
            
            # Do some processing
            $processed = $content | Where-Object { $_ -match '\S' } # Remove empty lines
            
            # Save results
            if ((Test-Path $OutputPath) -and -not $Force) {
                throw "Output file exists and -Force not specified"
            }
            $processed | Out-File $OutputPath -Force:$Force
        }
        
        Write-Output "Processing complete. Results saved to $OutputPath"
    }
    catch {
        Write-Error "Error processing files: $_"
        throw
    }
}

# Main execution
try {
    Write-Verbose "Starting script execution..."
    Process-Files -path $InputPath
}
catch {
    Write-Error "Script execution failed: $_"
    exit 1
}