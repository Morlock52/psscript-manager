function Get-SystemHealthCheck {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string[]]$ComputerName = $env:COMPUTERNAME,
        
        [Parameter(Mandatory=$false)]
        [int]$DiskThresholdGB = 10,
        
        [Parameter(Mandatory=$false)]
        [int]$CpuThreshold = 90
    )
    
    begin {
        $results = @()
        $date = Get-Date
    }
    
    process {
        foreach ($computer in $ComputerName) {
            try {
                Write-Verbose "Checking system health for computer: $computer"
                
                # Get CPU Usage
                $cpuLoad = Get-WmiObject Win32_Processor -ComputerName $computer |
                    Measure-Object -Property LoadPercentage -Average |
                    Select-Object -ExpandProperty Average
                
                # Get Memory Usage
                $os = Get-WmiObject Win32_OperatingSystem -ComputerName $computer
                $memoryUsage = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize * 100, 2)
                
                # Get Disk Space
                $disks = Get-WmiObject Win32_LogicalDisk -ComputerName $computer -Filter "DriveType=3"
                $diskInfo = $disks | ForEach-Object {
                    $freeSpaceGB = [math]::Round($_.FreeSpace / 1GB, 2)
                    @{
                        Drive = $_.DeviceID
                        FreeSpaceGB = $freeSpaceGB
                        Alert = $freeSpaceGB -lt $DiskThresholdGB
                    }
                }
                
                # Get Running Services Count
                $services = Get-Service -ComputerName $computer
                $runningServices = ($services | Where-Object {$_.Status -eq 'Running'}).Count
                $stoppedServices = ($services | Where-Object {$_.Status -eq 'Stopped'}).Count
                
                # Create Result Object
                $result = [PSCustomObject]@{
                    ComputerName = $computer
                    TimeStamp = $date
                    CPULoad = $cpuLoad
                    MemoryUsage = $memoryUsage
                    DiskInfo = $diskInfo
                    RunningServices = $runningServices
                    StoppedServices = $stoppedServices
                    Status = switch($true) {
                        ($cpuLoad -gt $CpuThreshold) { 'Critical - High CPU Usage' }
                        ($memoryUsage -gt 90) { 'Warning - High Memory Usage' }
                        ($diskInfo.Alert -contains $true) { 'Warning - Low Disk Space' }
                        default { 'Healthy' }
                    }
                }
                
                $results += $result
            }
            catch {
                Write-Error "Failed to check health for computer $computer. Error: $_"
            }
        }
    }
    
    end {
        # Return results
        return $results | Format-Table -AutoSize
    }
}

# Export results to HTML report
function Export-HealthReport {
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject[]]$HealthResults,
        
        [Parameter(Mandatory=$false)]
        [string]$ReportPath = "$env:USERPROFILE\Desktop\HealthReport.html"
    )
    
    $htmlHeader = @"
    <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .critical { color: red; }
        .warning { color: orange; }
        .healthy { color: green; }
    </style>
"@
    
    $htmlReport = $HealthResults | ConvertTo-Html -Head $htmlHeader
    $htmlReport | Out-File -FilePath $ReportPath
    
    Write-Host "Health report exported to: $ReportPath"
}
